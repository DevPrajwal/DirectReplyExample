package com.mycompany.myapp4;
import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;

public class NotificationSender extends Service
{

	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		// TODO: Implement this method
		if(intent != null)
		{
			PendingIntent pendingIntent = (PendingIntent) intent.getExtras().get("pIntent");
			Intent replyIntent = (Intent) intent.getExtras().get("rIntent");

			try
			{
				pendingIntent.send(this, 0, replyIntent);
			}
			catch(PendingIntent.CanceledException e)
			{
				Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
			}
		}
		
		return super.onStartCommand(intent, flags, startId);
	}
}
