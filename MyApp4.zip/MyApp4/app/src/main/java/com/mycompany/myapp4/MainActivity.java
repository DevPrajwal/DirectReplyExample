package com.mycompany.myapp4;

import android.app.*;
import android.os.*;
import android.content.*;
import android.widget.*;
 

public class MainActivity extends Activity
{ 
 
 	boolean NLConnected;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
    }

	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		if(getIntent() != null)
		{
			PendingIntent pendingIntent = (PendingIntent) getIntent().getExtras().get("pIntent");
			Intent replyIntent = (Intent) getIntent().getExtras().get("rIntent");

			try
			{
				pendingIntent.send(this, 0, replyIntent);
			}
			catch(PendingIntent.CanceledException e)
			{
				Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
			}
		}
		
		super.onResume();
	}
}
