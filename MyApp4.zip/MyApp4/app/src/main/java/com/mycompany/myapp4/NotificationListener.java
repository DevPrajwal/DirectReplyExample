package com.mycompany.myapp4;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.net.*;
import android.os.*;
import android.service.notification.*;
import java.net.*;


public class NotificationListener extends NotificationListenerService
{ 

	boolean NLConnected = false;

	@Override
	public void onListenerConnected()
	{
		// TODO: Implement this method
		super.onListenerConnected(); 
		NLConnected = true;
	} 

	@Override
	public void onNotificationPosted(StatusBarNotification sbn, NotificationListener.RankingMap rankingMap)
	{ 
		// TODO: Implement this method
		super.onNotificationPosted(sbn, rankingMap);  

		Notification.Action[] actions = sbn.getNotification().actions;

		//iterate through actions and find which one accepts direct reply
		for(Notification.Action act : actions)
		{
			if(act != null && act.getAllowGeneratedReplies() && act.actionIntent != null)
			{
				PendingIntent pendingIntent = act.actionIntent;

				Intent replyIntent = new Intent();
				Bundle replyBundle = new Bundle();

				if(act.getRemoteInputs() != null)
				{
					RemoteInput[] remoteInputs = act.getRemoteInputs();

					//filling the bundle with our message with each remoteInput
					for(RemoteInput rIn : remoteInputs)
						replyBundle.putCharSequence(rIn.getResultKey(), "~Automatically generated reply~");

					//filling the localIntent with localBundle
					RemoteInput.addResultsToIntent(remoteInputs, replyIntent, replyBundle);

					Intent intent;
					//Start Either an Activity
					intent = new Intent(NotificationListener.this, MainActivity.class);
					//Or a service
					intent = new Intent(NotificationListener.this, NotificationSender.class);
					intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					intent.putExtra("pIntent", pendingIntent);
					intent.putExtra("rIntent", replyIntent);
					startService(intent);
				}
			}
		}
	}

	@Override
	public void onListenerDisconnected()
	{
		// TODO: Implement this method
		super.onListenerDisconnected(); 
		NLConnected = false;
	}

	@Override
	public void onNotificationRemoved(StatusBarNotification sbn, NotificationListener.RankingMap rankingMap, int reason)
	{
		// TODO: Implement this method
		super.onNotificationRemoved(sbn, rankingMap, reason);
	} 
}
	 
